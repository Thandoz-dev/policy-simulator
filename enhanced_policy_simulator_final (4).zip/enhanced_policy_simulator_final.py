
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from fpdf import FPDF

# Coefficients from regression
b0 = 2.21016
b_gdfi = -0.93883
b_gov = -1.04625
b_trade = 0.20574
b_inflation = 0.26894

st.set_page_config(layout="wide")
st.title("📊 Macroeconomic Policy Simulator with Forecasts and Reports")

if "scenarios" not in st.session_state:
    st.session_state["scenarios"] = dict()

st.sidebar.markdown("## 🔮 Forecast Setup")
years_ahead = st.sidebar.slider("Years to Forecast", 1, 5, 3)
scenario_name = st.sidebar.text_input("Name Your Scenario", "Baseline Forecast")

st.markdown("## 📌 Base Year Assumptions")
gdfi = st.slider("GDFI (% of GDP)", 5.0, 30.0, 18.0)
gov_exp = st.slider("Government Expenditure (% of GDP)", 0.5, 10.0, 2.5)
trade = st.slider("Trade (% of GDP)", 20.0, 120.0, 60.0)
inflation = st.slider("Inflation Rate (%)", 0.0, 30.0, 5.0)

forecast = []
for i in range(1, years_ahead + 1):
    st.markdown(f"### 📅 Year +{i}")
    fgdfi = st.slider(f"GDFI Year +{i}", 5.0, 30.0, gdfi, key=f"gdfi_{i}")
    fgov = st.slider(f"GovExp Year +{i}", 0.5, 10.0, gov_exp, key=f"gov_{i}")
    ftrade = st.slider(f"Trade Year +{i}", 20.0, 120.0, trade, key=f"trade_{i}")
    finfl = st.slider(f"Inflation Year +{i}", 0.0, 30.0, inflation, key=f"inf_{i}")
    fgrowth = b0 + b_gdfi * fgdfi + b_gov * fgov + b_trade * ftrade + b_inflation * finfl
    forecast.append({
        "Year": f"Year +{i}",
        "GDFI": fgdfi,
        "GovExp": fgov,
        "Trade": ftrade,
        "Inflation": finfl,
        "GDP Growth": fgrowth
    })

df = pd.DataFrame(forecast)

st.markdown("## 📈 Forecast Results")
st.dataframe(df.set_index("Year"))

fig, ax = plt.subplots()
ax.plot(df["Year"], df["GDP Growth"], marker="o", linestyle="--")
ax.set_title("Forecasted GDP Growth")
ax.set_ylabel("Growth Rate (%)")
st.pyplot(fig)

summary = (
    f"Across the next {years_ahead} years, GDFI ranges from {df['GDFI'].min():.1f}% to {df['GDFI'].max():.1f}%. "
    f"Government expenditure and inflation remain within moderate bounds. The forecasted GDP growth ranges "
    f"from {df['GDP Growth'].min():.2f}% to {df['GDP Growth'].max():.2f}%, showing the impact of policy shifts "
    f"under current macroeconomic conditions."
)

st.markdown("## 🧠 GPT-style Simulation Summary")
st.info(summary)

if st.button("💾 Save Scenario"):
    st.session_state["scenarios"][scenario_name] = df.copy()
    st.success(f"Scenario '{scenario_name}' saved.")

if st.session_state["scenarios"]:
    st.markdown("## 📂 Saved Scenarios")
    for name, data in st.session_state["scenarios"].items():
        st.markdown(f"**{name}**")
        st.dataframe(data.set_index("Year"))

if st.button("📄 Export Forecast Report to PDF"):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Macroeconomic Policy Forecast Report", ln=True, align="C")
    pdf.ln(10)
    pdf.set_font("Arial", size=10)
    for col in df.columns:
        pdf.cell(38, 10, col[:15], 1)
    pdf.ln()
    for _, row in df.iterrows():
        for col in df.columns:
            val = f"{row[col]:.2f}" if isinstance(row[col], float) else str(row[col])
            pdf.cell(38, 10, val, 1)
        pdf.ln()
    pdf.ln(5)
    pdf.set_font("Arial", size=11)
    pdf.multi_cell(0, 10, f"Scenario: {scenario_name}

Insight:
{summary}")
    path = "forecast_simulation_report.pdf"
    pdf.output(path)
    with open(path, "rb") as file:
        st.download_button("⬇️ Download PDF Report", data=file, file_name=path, mime="application/pdf")
